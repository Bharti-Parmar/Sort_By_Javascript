// 1
  console.log(TABLE_DATA);
function table(){
  var content = '';
  for(let x in TABLE_DATA){

    let name = TABLE_DATA[x]['name'].replace("<","&lt");

    content = content + `<tr><td>${TABLE_DATA[x]['id']}</td><td>${name}</td><td>${TABLE_DATA[x]['thumbnailUrl']}</td><td>${TABLE_DATA[x]['price']}</td></tr>`;
  }

  document.getElementById('tdata').innerHTML = content;
}
// 2
var  s ;

  function sortdata(){

  s = setInterval(function() { sortTable();
            }, 1000);
    }

// 3

  function stopsort(){
    clearInterval(s);
  }

  function sortTable() {
  let table = TABLE_DATA;

  // let rowsCollection = table.querySelectorAll("tr");
  // let rows = Array.from(rowsCollection).slice(1);

  shuffleArray(TABLE_DATA);

  table2(TABLE_DATA);
}


function shuffleArray(array) {
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }
}


// var data = [{ "id": "105", "name": "FIAT", "active": true, "parentId": "1" },
// { "id": "106", "name": "AUDI", "active": true, "parentId": "1" },
// { "id": "107", "name": "BMW", "active": true, "parentId": "1" },
// { "id": "109", "name": "RENAULT", "active": true, "parentId": "1" }
// ];


// document.write('<pre>' + JSON.stringify(TABLE_DATA, 0, 4) + '</pre>');
function test(){
  TABLE_DATA.sort(function (a, b) {
      return a.id - b.id;
  });
  table2(TABLE_DATA);
}
function table2(data){
  var content = '';
  for(let x in data){

    let name = data[x]['name'].replace("<","&lt");

    content = content + `<tr><td>${data[x]['id']}</td><td>${name}</td><td>${data[x]['thumbnailUrl']}</td><td>${data[x]['price']}</td></tr>`;
  }

  document.getElementById('tdata').innerHTML = content;
}
// 3
// var sortbyKey = sortByKey(TABLE_DATA);
// console.table(sortbyKey);
//
// function sort(TABLE_DATA){
//
//     for(let i in TABLE_DATA)
//     {
//         sorted.push([i, id[i]]);
//     }
//
//     return sortedKeys.sort();
// }
//
// // second method
//
// function sort(TABLE_DATA){
//   let keys = [id];
//   let sortedKeys = [...TABLE_DATA];
//
//     for (let i in sortedKeys.length) {
//        let key = sortedKeys[i];
//       addObjectToTable(json[id]);
//     }
//
//     return sortedKeys.sort();
// }
